﻿public class TreeNode
{
    public string Value { get; set; }
    public TreeNode Left { get; set; }
    public TreeNode Right { get; set; }

    public TreeNode(string value)
    {
        Value = value;
        Left = null;
        Right = null;
    }

    public void PrintTree(string indent = "")
    {
        Console.WriteLine(indent + Value);

        if (Left != null)
        {
            Left.PrintTree(indent + "  ");
        }

        if (Right != null)
        {
            Right.PrintTree(indent + "  ");
        }
    }

    public void PrintTreeIndented(TreeNode node, string indent = "")
    {
        if (node == null)
        {
            return;
        }

        Console.WriteLine(indent + node.Value);

        if (node.Left != null || node.Right != null)
        {
            PrintTreeIndented(node.Left, indent + "  ");
            PrintTreeIndented(node.Right, indent + "  ");
        }
    }
    public string[] GetFunctionParameters()
    {
        List<string> parameters = new List<string>();
        GetFunctionParametersHelper(this.Left, parameters);
        return parameters.ToArray();
    }

    private void GetFunctionParametersHelper(TreeNode node, List<string> parameters)
    {
        if (node == null)
        {
            return;
        }

        if (Char.IsLetterOrDigit(node.Value[0]))
        {
            // Възелът съдържа буква или цифра, следователно е параметър
            parameters.Add(node.Value);
        }

        // Рекурсивно извикване за ляво и за дясно поддърво
        GetFunctionParametersHelper(node.Left, parameters);
        GetFunctionParametersHelper(node.Right, parameters);
    }
}