﻿using MyExtensions;
using System.Data;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;

namespace Project;

public class Program
{
    static void Main()
    {
        //Обратен полски запис
        RPN rpnConverter = new RPN();

        MyDictionary<string, string> expressions = new MyDictionary<string, string>();

        while (true)
        {

            string[] data = Console.ReadLine().MySplit(" ");

            if (data[0] == "End")
            {
                break;
            }

            if (data[0] == "DEFINE")
            {
                string funcName = GetName(data[1]);
                string expression = GetExpression(data[2]);

                bool contains = ExpressionContainsAnotherFuncs(expressions, expression);

                //без вложен func
                if (!contains)
                {
                    if (ChechParametersEquality(data))
                    {
                        expressions.Add(funcName, expression);
                    }
                    else
                    {
                        Console.WriteLine("Wrong input");
                    }

                }
                //с вложен func
                else
                {
                    foreach (var ex in expressions)
                    {
                        string nestedFunction = ex.Key;
                        string nestedFunctionValue = ex.Value;

                        // Проверка дали вложената функция се среща в израза
                        if (expression.MyContains(nestedFunction))
                        {
                            // Заместване на вложената функция със съответната стойност на съществуващата в Dictionary
                            expression = expression.Replace(nestedFunction, $"({nestedFunctionValue})");
                        }
                    }

                    //проверка дали след заместването е останал някоЙ func => e имал невалидни параметри => е невалиден
                    if (expression.MyContains("func"))
                    {
                        Console.WriteLine("Wrong input");
                    }
                    else
                    {

                        expressions.Add(funcName, expression);
                    }


                }
            }
            else if (data[0] == "Print")
            {

                string func = data[1];

                //проверяваме дали има такава запазена функция в Dictionary
                if (expressions.ContainsKey(func))
                {
                    string rpn = rpnConverter.InfixToRPN(expressions[func]);
                    TreeNode root = rpnConverter.FindRoot(rpn);

                    // Принтиране на структурата на дървото
                    Console.WriteLine("Expression Tree:");
                    root.PrintTree();
                }
                else
                {
                    Console.WriteLine("Wrong input");
                }
            }
        }

        

    }


    //не се използва за сега
    private static string FindNestedFunction(string expression)
    {
        int idx = expression.IndexOf("func");
        int endIdx = expression.IndexOf(")", idx) + 1;
        string neededEx = expression.Substring(idx, endIdx - idx);
        return neededEx;
    }

    private static bool ChechParametersEquality(string[] data)
    {
        string[] parameters = FindParameters(data[1]);
        string[] expressionParameters = FindParametersFromExpression(data[2]);

        if (parameters.Length != expressionParameters.Length)
        {
            return false;
        }

        foreach (var item in parameters)
        {
            if (!expressionParameters.MyContains(item))
            {
                return false;
            }
        }

        return true;
    }

    private static string[] FindParametersFromExpression(string v)
    {
        MyList<char> paramss = new MyList<char>();
        foreach (char ch in v)
        {
            if ((int)ch >= 97 && (int)ch <= 122)
            {
                paramss.Add(ch);
            }
        }

        string[] stringArray = new string[paramss.Count];

        for (int i = 0; i < paramss.Count; i++)
        {
            stringArray[i] = paramss[i].ToString();
        }

        return stringArray;
    }

    private static string[] FindParameters(string v)
    {
        int parenthesis = v.MyIndexOf("(");
        int closingPar = v.MyIndexOf(")");
        string needed = v.MySubstring(parenthesis + 1, closingPar - parenthesis - 1);
        string[] paramss = needed.MySplit(",");
        return paramss;
    }

    private static bool ExpressionContainsAnotherFuncs(MyDictionary<string, string> expressions, string expression)
    {
        foreach (var item in expressions)
        {
            if (expression.MyContains(item.Key))
            {
                return true;
            }
        }

        return false;
    }

    private static string GetExpression(string v)
    {
        string expression = v.MySubstring(1, v.Length - 2);
        return expression;
    }

    private static string GetName(string expression)
    {
        int idxParenthesis = expression.MyIndexOf(":");
        string name = expression.MySubstring(0, idxParenthesis);
        return name;
    }









}





